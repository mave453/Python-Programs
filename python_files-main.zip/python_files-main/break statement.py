
a = [7, 1, 3, 5, 9, 11]
val = 7

for i in a:
    if i == val:
        print(i)
        break
else:
    print("not found")
