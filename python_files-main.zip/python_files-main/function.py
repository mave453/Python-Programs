def add(x,y):
    return x+y
a,b=map(int,input().split())
print(add(a,b))
print("hell")
def add(x,y):
    return x+y
a,b=map(int,input().split())
print(add(a,b))
print("hell")