    """
   if statements
   ifelse statements
   nested if statements
   elif statements
   else statements
   
    
    """
n=90
if n>=90 and n<=100:
    print("Grade A")
elif n>=80 and n<90:
    print("Grade B")
elif n>=70 and n<80:
    print("Grade C")
elif n>=60 and n<70:
    print("Grade D")
else:
    print("Fail")