'''

& : Bitwise AND
| : Bitwise OR
^ : Bitwise XOR
~ : Bitwise NOT
<< : Bitwise Left Shift
>> : Bitwise Right Shift
'''

n=int(input("Enter a number: "))
print(n|3)  
print(n&3)
print(n^3)
print(~n)
print(n<<2)
print(n>>2)
