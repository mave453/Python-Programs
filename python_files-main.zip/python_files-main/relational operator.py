"""
<,>,<=,>=,!=,==

"""
n=int(input ("Enter a number: "))
if n>0:
    print("Positive")
elif n<0:           
    print("Negative")
else:
    print("Zero")
k=10
if k//2==5:
    print("k is even")
else:
    print("k is odd")
    
S="Hello"
if S=="Hello":
    print("String is Hello")
else:
    print("String is not Hello")




