k=int(input("Enter a number: "))
if k>0 or k%2==0:
    print("k is either positive or even")
else:
    print("k is neither positive nor even")
    
x=int(input("Enter a number: "))
if x>0 and x%2==0:
    print("x is positive and even")
else:
    print("x is either not positive or not even")   
    
s=10
t=20
if not (s>t):
    print("s is not greater than t")
else:
    print("s is greater than t")
    
    