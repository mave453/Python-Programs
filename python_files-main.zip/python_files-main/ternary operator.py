n=int(input("Enter a number: "))
result="Positive" if n>0 else "Negative" if n<0 else "Zero"
print(result)
